package com.site.lms.dto;

import java.util.List;
import java.util.Map;

public class VideoProcessResponse {
    private String filename;
    private List<String> tokens;
    private List<List<Object>> top_keywords;
    private List<Map<String, Object>> segments;
    private String raw_text;

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public List<String> getTokens() {
        return tokens;
    }

    public void setTokens(List<String> tokens) {
        this.tokens = tokens;
    }

    public List<List<Object>> getTop_keywords() {
        return top_keywords;
    }

    public void setTop_keywords(List<List<Object>> top_keywords) {
        this.top_keywords = top_keywords;
    }

    public List<Map<String, Object>> getSegments() {
        return segments;
    }

    public void setSegments(List<Map<String, Object>> segments) {
        this.segments = segments;
    }

    public String getRaw_text() {
        return raw_text;
    }

    public void setRaw_text(String raw_text) {
        this.raw_text = raw_text;
    }
}