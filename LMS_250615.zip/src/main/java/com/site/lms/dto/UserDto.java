package com.site.lms.dto;

public record UserDto(String username, String password) {}
