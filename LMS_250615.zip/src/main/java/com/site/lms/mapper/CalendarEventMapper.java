package com.site.lms.mapper;

import java.time.LocalDate;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.site.lms.entity.CalendarEvent;

@Mapper
public interface CalendarEventMapper 
{
    void insert(
        @Param("memberNo") Long memberNo,
        @Param("videoNo") Long videoNo,
        @Param("eventDate") LocalDate eventDate
    );
    List<CalendarEvent> findByMember(@Param("memberNo") Long memberNo);
    void updateStatus(
        @Param("eventId") Long eventId,
        @Param("status") String status
    );
    void shiftEvent(
        @Param("eventId") Long eventId,
        @Param("newDate") LocalDate newDate
    );
    void deleteEvent(@Param("eventId") Long eventId);
    void deleteByLecture(
        @Param("memberNo") Long memberNo,
        @Param("lectureNo") Long lectureNo
    );
}