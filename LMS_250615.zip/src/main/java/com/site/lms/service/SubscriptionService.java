// src/main/java/com/site/lms/service/SubscriptionService.java
package com.site.lms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.site.lms.entity.Subscription;
import com.site.lms.mapper.SubscriptionMapper;

@Service
public class SubscriptionService {
    private final SubscriptionMapper mapper;

    public SubscriptionService(SubscriptionMapper mapper) {
        this.mapper = mapper;
    }

    /** 학생이 아직 신청하지 않았다면 PENDING 상태로 한 번만 insert */
    public void requestSubscription(Long memberNo, Long lectureNo) {
        var existing = mapper.findByMemberAndLecture(memberNo, lectureNo);
        if (existing == null) {
            Subscription sub = new Subscription();
            sub.setMemberNo(memberNo);
            sub.setLectureNo(lectureNo);
            sub.setStatus("PENDING");
            mapper.insert(sub);
        }
    }

    /** 강사 화면에서 해당 강의(sub.lectureNo) 신청 목록 조회할 때 사용 */
    public List<Subscription> getSubscriptions(Long lectureNo) {
        return mapper.findByMember(lectureNo);
    }

    /** 이미 신청했는지 여부 체크 */
    public boolean isSubscribed(Long memberNo, Long lectureNo) {
        return mapper.findByMemberAndLecture(memberNo, lectureNo) != null;
    }

    /** subId 로 단건 조회 (APPROVE/REJECT 처리 시 사용) */
    public Optional<Subscription> getById(Long subId) {
        return Optional.ofNullable(mapper.findById(subId));
    }

    /** subId 의 상태를 APPROVED 또는 REJECTED 로 변경 */
    public void updateStatus(Long subId, String status) {
        mapper.updateStatus(subId, status);
    }
}