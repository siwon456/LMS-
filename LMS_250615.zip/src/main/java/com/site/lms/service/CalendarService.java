// src/main/java/com/site/lms/service/CalendarService.java
package com.site.lms.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;

import com.site.lms.entity.CalendarEvent;
import com.site.lms.entity.LectureVideo;
import com.site.lms.mapper.CalendarEventMapper;

@Service
public class CalendarService {

    private final CalendarEventMapper mapper;
    private final LectureVideoService lectureVideoService;

    public CalendarService(CalendarEventMapper mapper,
                           LectureVideoService lectureVideoService) {
        this.mapper = mapper;
        this.lectureVideoService = lectureVideoService;
    }

    /**
     * 회원의 모든 캘린더 이벤트 상태 업데이트
     */
    public void updateStatuses(Long memberNo) {
        LocalDate today = LocalDate.now();
        List<CalendarEvent> events = mapper.findByMember(memberNo);
        for (CalendarEvent ev : events) {
            if (ev.getEventDate() == null) continue;
            String newStatus;
            Integer pct = ev.getProgressPct();
            if (pct != null && pct >= 100) {
                newStatus = "COMPLETED";
            } else if (ev.getEventDate().isBefore(today)) {
                newStatus = "MISSED";
            } else {
                newStatus = "PENDING";
            }
            if (!newStatus.equals(ev.getStatus())) {
                mapper.updateStatus(ev.getEventId(), newStatus);
                ev.setStatus(newStatus);
            }
        }
    }

    /**
     * 공개 강의 선택 시, 해당 강의의 모든 챕터를 오늘부터 
     * 하루씩 추가하여 캘린더 이벤트 생성
     */
    public void addLectureSchedule(Long memberNo, Long lectureNo) {
        List<LectureVideo> videos = lectureVideoService.findByLectureNo(lectureNo);
        LocalDate date = LocalDate.now();
        for (LectureVideo vid : videos) {
            mapper.insert(memberNo, vid.getVideoNo(), date);
            date = date.plusDays(1);
        }
    }

    /**
     * 특정 이벤트를 새 날짜로 이동 (쉬는 날 기능)
     */
    public void shiftSchedule(Long eventId, LocalDate newDate) {
        mapper.shiftEvent(eventId, newDate);
    }

    /**
     * 회원의 모든 캘린더 이벤트 조회
     */
    public List<CalendarEvent> getEventsForMember(Long memberNo) {
        return mapper.findByMember(memberNo);
    }

    /**
     * 개별 이벤트 삭제 (캘린더에서 제거)
     */
    public void removeEvent(Long eventId) {
        mapper.deleteEvent(eventId);
    }

    /**
     * 강의 단위로 캘린더 전체 제거 (캘린더 제거 버튼용)
     */
    public void removeLectureSchedule(Long memberNo, Long lectureNo) {
        mapper.deleteByLecture(memberNo, lectureNo);
    }
}