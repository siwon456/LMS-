package com.site.lms.controller;

import java.security.Principal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.site.lms.dto.InstructorStudentDto;
import com.site.lms.entity.Lecture;
import com.site.lms.service.LectureApplicationService;
import com.site.lms.service.LectureService;
import com.site.lms.service.LectureVideoService;
import com.site.lms.service.ProgressService;
import com.site.lms.service.SubscriptionService;
import com.site.lms.service.UserService;

@Controller
@RequestMapping("/instructor")
public class InstructorStudentsController {

    private final SubscriptionService       subscriptionService;
    private final LectureApplicationService applicationService;
    private final UserService               userService;
    private final LectureService            lectureService;
    private final LectureVideoService       videoService;
    private final ProgressService           progressService;

    public InstructorStudentsController(
        SubscriptionService       subscriptionService,
        LectureApplicationService applicationService,
        UserService               userService,
        LectureService            lectureService,
        LectureVideoService       videoService,
        ProgressService           progressService
    ) {
        this.subscriptionService = subscriptionService;
        this.applicationService  = applicationService;
        this.userService         = userService;
        this.lectureService      = lectureService;
        this.videoService        = videoService;
        this.progressService     = progressService;
    }

    @GetMapping("/students")
    public String listAllStudents(Model model, Principal principal) {
        Long instructorId = userService.findByUsername(principal.getName())
                                       .orElseThrow()
                                       .getId();

        Map<Lecture, List<InstructorStudentDto>> map =
            lectureService.findByInstructor(instructorId).stream()
                .collect(Collectors.toMap(
                    lec -> lec,
                    lec -> subscriptionService.getSubscriptions(lec.getLectureNo()).stream()
                        .filter(sub -> "PENDING".equals(sub.getStatus()))
                        .map(sub -> {
                            var student = userService.findById(sub.getMemberNo())
                                                     .orElseThrow();
                            int pct = progressService.getLectureProgress(
                                student.getUsername(),
                                lec.getLectureNo(),
                                videoService.findByLectureNo(lec.getLectureNo())
                            );
                            return new InstructorStudentDto(
                                sub.getSubId(),
                                student.getUsername(),
                                pct,
                                sub.getStatus()
                            );
                        })
                        .toList()
                ));

        model.addAttribute("map", map);
        return "instructor_students";
    }

    @PostMapping("/students/{subId}/accept")
    public String acceptSubscription(
        @PathVariable("subId") Long subId,
        Principal principal
    ) {
        applicationService.acceptApplication(principal.getName(), subId);
        return "redirect:/instructor/students";
    }

    @PostMapping("/students/{subId}/reject")
    public String rejectSubscription(
        @PathVariable("subId") Long subId,
        Principal principal
    ) {
        applicationService.rejectApplication(principal.getName(), subId);
        return "redirect:/instructor/students";
    }
}
