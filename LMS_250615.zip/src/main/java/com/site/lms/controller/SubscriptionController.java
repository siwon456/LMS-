// src/main/java/com/site/lms/controller/SubscriptionController.java
package com.site.lms.controller;

import java.security.Principal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.site.lms.service.LectureApplicationService;
import com.site.lms.service.LectureService;
import com.site.lms.service.UserService;

@Controller
@RequestMapping("/lectures")
public class SubscriptionController {

    private final LectureService lectureService;
    private final UserService userService;
    private final LectureApplicationService applicationService;

    public SubscriptionController(
            LectureService lectureService,
            UserService userService,
            LectureApplicationService applicationService
    ) {
        this.lectureService      = lectureService;
        this.userService         = userService;
        this.applicationService  = applicationService;
    }

    /**
     * GET  /lectures/apply
     * 비공개 강의 목록을 보여주는 신청 페이지
     */
    @GetMapping("/apply")
    public String showApplyPage(Model model) {
        // visibility=0 인 비공개 강의만
        model.addAttribute("privateLectures", lectureService.findByVisibility(0));
        return "lectures_apply";
    }

    /**
     * POST /lectures/subscribe
     * 비공개 강의 신청 처리 (DB 저장 + 강사에게 메시지 발송)
     */
    @PostMapping("/subscribe")
    public String subscribe(
            @RequestParam("lectureNo") Long lectureNo,
            Principal principal
    ) {
        // 1) 로그인 학생 ID 조회
        var student = userService.findByUsername(principal.getName())
                         .orElseThrow(() -> new IllegalArgumentException("사용자를 찾을 수 없습니다."));
        // 2) 신청 로직 및 메시지 발송
        applicationService.applyToLecture(student.getId(), lectureNo);
        // 3) 다시 신청 페이지로 리다이렉트 (요청 성공 표시를 쿼리파라미터로 넘길 수도 있습니다)
        return "redirect:/lectures/apply?success";
    }
}