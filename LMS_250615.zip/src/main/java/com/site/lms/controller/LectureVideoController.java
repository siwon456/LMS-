package com.site.lms.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.site.lms.dto.VideoProcessResponse;
import com.site.lms.entity.LectureVideo;
import com.site.lms.service.LectureVideoService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/videos")
public class LectureVideoController {

    private final LectureVideoService lectureVideoService;
    private static final Logger logger = LoggerFactory.getLogger(LectureVideoController.class);
    private final String FLASK_API_URL = "http://localhost:5000/api/process";
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    public LectureVideoController(LectureVideoService lectureVideoService) {
        this.lectureVideoService = lectureVideoService;
    }

    @GetMapping("/analyze")
    public ResponseEntity<?> analyzeVideo(
        @RequestParam("videoPath") String videoPath,
        @RequestParam("lectureNo") Long lectureNo) {
        try {
            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, String> request = Map.of("video_path", videoPath);
            HttpEntity<Map<String, String>> entity = new HttpEntity<>(request, headers);

            ResponseEntity<VideoProcessResponse> response = restTemplate.postForEntity(
                FLASK_API_URL, entity, VideoProcessResponse.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                VideoProcessResponse data = response.getBody();

                // 🛠 변경: lectureVideoService.saveVideo(...) 호출
                LectureVideo video = new LectureVideo();
                video.setLectureNo(lectureNo);
                video.setVideoPath(videoPath);
                video.setVideoDesc("자동 분석된 영상");
                video.setWordset(objectMapper.writeValueAsString(data.getTop_keywords()));
                video.setRawText(data.getRaw_text());
                video.setSegmentsJson(objectMapper.writeValueAsString(data.getSegments()));
                video.setVisibility(1); // 기본 공개 설정
                lectureVideoService.saveVideo(video);

                logger.info("✅ Flask 분석 완료: [{}], 키워드 {}개",
                            data.getFilename(), data.getTop_keywords().size());

                return ResponseEntity.ok(data);
            }
            return ResponseEntity.status(500).body("전처리 실패");
        } catch (Exception e) {
            logger.error("❌ Flask 연동 오류: {}", e.getMessage(), e);
            return ResponseEntity.status(500).body("에러: " + e.getMessage());
        }
    }
}
