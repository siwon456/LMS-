package com.site.lms.controller;

import java.security.Principal;
import java.util.*;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.site.lms.entity.CalendarEvent;
import com.site.lms.entity.Lecture;
import com.site.lms.entity.LectureVideo;
import com.site.lms.entity.Subscription;
import com.site.lms.entity.User;
import com.site.lms.service.CalendarService;
import com.site.lms.service.LectureService;
import com.site.lms.service.LectureVideoService;
import com.site.lms.service.SubscriptionService;
import com.site.lms.service.UserService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainHome {

    private final UserService userService;
    private final CalendarService calendarService;
    private final LectureService lectureService;
    private final LectureVideoService lectureVideoService;
    private final SubscriptionService subscriptionService;
    private final ObjectMapper objectMapper;

    public MainHome(UserService userService,
                    CalendarService calendarService,
                    LectureService lectureService,
                    LectureVideoService lectureVideoService,
                    SubscriptionService subscriptionService,
                    ObjectMapper objectMapper) {
        this.userService = userService;
        this.calendarService = calendarService;
        this.lectureService = lectureService;
        this.lectureVideoService = lectureVideoService;
        this.subscriptionService = subscriptionService;
        this.objectMapper = objectMapper;
    }

    @GetMapping("/")
    public String mainHome(Model model, Principal principal) throws Exception {
        if (principal != null) {
            User user = userService.findByUsername(principal.getName()).orElseThrow();
            Long memberNo = user.getId();
            model.addAttribute("username", user.getUsername());
            model.addAttribute("authority", user.getAuthority());

            // 캘린더 이벤트 JSON 생성
            calendarService.updateStatuses(memberNo);
            List<CalendarEvent> events = calendarService.getEventsForMember(memberNo);
            model.addAttribute("eventsJson", objectMapper.writeValueAsString(events));

            // 공개 강의 + 영상 목록
            List<Lecture> publicLectures = lectureService.findByVisibility(1);
            Map<Long, List<LectureVideo>> videosByLecture = new LinkedHashMap<>();
            for (Lecture lec : publicLectures) {
                videosByLecture.put(
                    lec.getLectureNo(),
                    lectureVideoService.findByLectureNo(lec.getLectureNo())
                );
            }
            model.addAttribute("publicLectures", publicLectures);
            model.addAttribute("videosByLecture", videosByLecture);

            // 이미 캘린더에 추가된 lectureNo 집합 계산
            Set<Long> scheduledLectureNos = new HashSet<>();
            Set<Long> evVideoNos = events.stream()
                                         .map(CalendarEvent::getVideoNo)
                                         .collect(Collectors.toSet());
            for (Lecture lec : publicLectures) {
                for (LectureVideo vid : videosByLecture.get(lec.getLectureNo())) {
                    if (evVideoNos.contains(vid.getVideoNo())) {
                        scheduledLectureNos.add(lec.getLectureNo());
                        break;
                    }
                }
            }
            model.addAttribute("scheduledLectures", scheduledLectureNos);

            // 비공개 강의 + 구독된 강의 번호 집합
            List<Lecture> privateLectures = lectureService.findByVisibility(0);
            model.addAttribute("privateLectures", privateLectures);

            List<Subscription> subs = subscriptionService.getSubscriptions(memberNo);
            Set<Long> subscribedNos = subs.stream()
                                          .map(Subscription::getLectureNo)
                                          .collect(Collectors.toSet());
            model.addAttribute("subscribedNos", subscribedNos);
        }
        return "mainHome";
    }
}